Those documentations are self notes
I am sharing this because this is better than nothing
Maybe you can get some hint from this?