Most codes are researched for Cosmos mod
May not accurate or incomplete (or both)